@echo off
call mvn clean compile spring-boot:run
pause
