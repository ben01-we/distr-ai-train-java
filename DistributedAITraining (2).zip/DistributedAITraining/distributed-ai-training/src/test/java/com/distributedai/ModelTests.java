package com.distributedai;

import com.distributedai.util.ModelFactory;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.junit.jupiter.api.Test;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ModelTests - Basic sanity checks for model architecture and training.
 *
 * Run with: mvn test
 */
class ModelTests {

    @Test
    void testMLPOutputShape() {
        MultiLayerNetwork model = ModelFactory.buildMLP(10, 4);

        INDArray input  = Nd4j.randn(5, 10);   // batch=5, features=10
        INDArray output = model.output(input);

        assertEquals(5, output.rows(),    "Batch size should be preserved");
        assertEquals(4, output.columns(), "Output should have 4 class probabilities");
    }

    @Test
    void testSoftmaxOutputSumsToOne() {
        MultiLayerNetwork model = ModelFactory.buildMLP(10, 4);
        INDArray input  = Nd4j.randn(10, 10);
        INDArray output = model.output(input);

        // Each row (sample) should sum to ~1.0 (softmax property)
        INDArray rowSums = output.sum(1);
        for (int i = 0; i < rowSums.length(); i++) {
            assertEquals(1.0, rowSums.getDouble(i), 1e-5,
                    "Softmax row " + i + " should sum to 1.0");
        }
    }

    @Test
    void testModelTrainsAndReducesLoss() {
        MultiLayerNetwork model = ModelFactory.buildMLP(10, 4);

        // Generate small training set
        INDArray X = Nd4j.randn(100, 10);
        INDArray y = Nd4j.zeros(100, 4);
        for (int i = 0; i < 100; i++) y.putScalar(new int[]{i, i % 4}, 1.0);
        DataSet data = new DataSet(X, y);

        double lossBeforeTraining = model.score(data);
        for (int i = 0; i < 50; i++) model.fit(data);
        double lossAfterTraining = model.score(data);

        assertTrue(lossAfterTraining < lossBeforeTraining,
                String.format("Loss should decrease: before=%.4f after=%.4f",
                        lossBeforeTraining, lossAfterTraining));
    }

    @Test
    void testParameterCountIsCorrect() {
        MultiLayerNetwork model = ModelFactory.buildMLP(10, 4);

        // Layer 0: 10*256 weights + 256 bias = 2816
        // Layer 1: 256*128 weights + 128 bias = 32896
        // Layer 2: 128*4 weights + 4 bias = 516
        // Total = 36228
        long expectedParams = (10 * 256 + 256) + (256 * 128 + 128) + (128 * 4 + 4);
        assertEquals(expectedParams, model.numParams(),
                "Parameter count should match architecture definition");
    }
}
