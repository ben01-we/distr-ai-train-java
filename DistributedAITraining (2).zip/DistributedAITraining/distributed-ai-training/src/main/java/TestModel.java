import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.learning.config.Adam;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.nd4j.linalg.api.ndarray.INDArray;

public class TestModel {
    public static void main(String[] args) {
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(42L)
                .weightInit(WeightInit.XAVIER)
                .updater(new Adam(0.01))
                .list()
                .layer(new OutputLayer.Builder(LossFunctions.LossFunction.MSE)
                        .nIn(3).nOut(1)
                        .activation(Activation.IDENTITY)
                        .build())
                .build();
        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();
        
        INDArray w = model.getLayer(0).getParam("W");
        if (w == null) {
            System.out.println("W is null!");
        } else {
            System.out.println("W shape: " + java.util.Arrays.toString(w.shape()));
            if (w.shape().length >= 1) System.out.println("size(0): " + w.size(0));
            if (w.shape().length >= 2) System.out.println("size(1): " + w.size(1));
        }

        try {
            long nIn = ((org.deeplearning4j.nn.conf.layers.FeedForwardLayer) model.getLayer(0).conf().getLayer()).getNIn();
            System.out.println("FeedForwardLayer getNIn: " + nIn);
        } catch(Exception e) {
            System.out.println("FeedForwardLayer cast failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
