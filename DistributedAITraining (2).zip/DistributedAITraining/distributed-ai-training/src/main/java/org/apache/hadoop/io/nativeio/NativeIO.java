package org.apache.hadoop.io.nativeio;

public class NativeIO {
    private static boolean nativeLoaded = false;
    private static boolean workaroundInitialized = false;

    public static boolean isAvailable() {
        return false;
    }

    public static class Windows {
        public static boolean access0(String path, int requestedAccess) {
            return true;
        }
        public static boolean access(String path, NativeIO.Windows.AccessRight requestedAccess) {
            return true;
        }
        public static void extendWorkingSetSize(long ext) { }
        public static enum AccessRight {
            ACCESS_READ(256),
            ACCESS_WRITE(512),
            ACCESS_EXECUTE(32);
            private final int accessRight;
            AccessRight(int access) { accessRight = access; }
            public int accessRight() { return accessRight; }
        }
    }
}
