package com.distributedai.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * WebSocketConfig - STOMP over WebSocket for real-time epoch streaming.
 *
 * Frontend connects to:   ws://localhost:8080/ws
 * Subscribe to metrics:   /topic/training/{jobId}
 *
 * Each epoch the backend broadcasts an EpochMetric JSON object,
 * which the frontend uses to update the live loss chart and progress bar.
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // In-memory broker for /topic/** destinations
        config.enableSimpleBroker("/topic");
        // Prefix for messages FROM the client (not used in this project)
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*")  // Allow frontend on any origin
                .withSockJS();                   // SockJS fallback for older browsers
    }
}
