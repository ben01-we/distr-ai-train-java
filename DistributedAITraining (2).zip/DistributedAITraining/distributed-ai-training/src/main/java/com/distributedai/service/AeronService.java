package com.distributedai.service;

import com.distributedai.config.DistributedConfig;
import com.distributedai.model.dto.Dtos;
import io.aeron.Aeron;
import io.aeron.Publication;
import io.aeron.Subscription;
import io.aeron.driver.MediaDriver;
import org.agrona.BufferUtil;
import org.agrona.concurrent.UnsafeBuffer;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.nio.ByteBuffer;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * AeronService — Spring-managed Aeron gradient sync service.
 *
 * Provides:
 *   - Lifecycle management (init/destroy) of the Aeron MediaDriver
 *   - Gradient publish/subscribe for distributed training
 *   - Loopback testing for verifying Aeron connectivity
 *   - Real-time gradient sync metrics streamed to the frontend via WebSocket
 *
 * WebSocket destination: /topic/aeron-metrics
 */
@Service
public class AeronService {

    private static final Logger log = LoggerFactory.getLogger(AeronService.class);

    @Autowired
    private DistributedConfig config;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    private MediaDriver mediaDriver;
    private Aeron aeron;
    private final AtomicBoolean initialized = new AtomicBoolean(false);

    // ── Metrics tracking ──────────────────────────────────────────────────────
    private final AtomicLong totalGradientsSent = new AtomicLong(0);
    private final AtomicLong totalGradientsReceived = new AtomicLong(0);
    private final AtomicLong totalBytesSent = new AtomicLong(0);
    private final CopyOnWriteArrayList<Dtos.GradientSyncMetric> recentMetrics = new CopyOnWriteArrayList<>();
    private static final int MAX_RECENT_METRICS = 50;

    @PostConstruct
    public void init() {
        if (!config.getAeron().isEnabled()) {
            log.info("Aeron gradient sync is DISABLED (distributed.aeron.enabled=false)");
            return;
        }
        try {
            MediaDriver.Context driverCtx = new MediaDriver.Context()
                    .dirDeleteOnStart(true)
                    .dirDeleteOnShutdown(true);
            this.mediaDriver = MediaDriver.launchEmbedded(driverCtx);

            Aeron.Context aeronCtx = new Aeron.Context()
                    .aeronDirectoryName(mediaDriver.aeronDirectoryName());
            this.aeron = Aeron.connect(aeronCtx);

            initialized.set(true);
            log.info("🚀 Aeron gradient sync initialized system-wide. Channel: {}", config.getAeron().getChannel());
        } catch (Throwable e) {
            // Aeron's MediaDriver may throw ExceptionInInitializerError on newer JVMs
            // (Java 25+) due to module access restrictions on sun.nio.ch.
            // This is non-fatal — the app works fine without Aeron, just no gradient sync.
            log.warn("Failed to initialize Aeron (non-fatal, app will still work): {}", e.getMessage());
            log.info("To enable Aeron, add JVM flag: --add-opens java.base/sun.nio.ch=ALL-UNNAMED");
            initialized.set(false);
        }
    }

    @PreDestroy
    public void shutdown() {
        if (aeron != null) {
            try { aeron.close(); } catch (Exception e) { /* ignore */ }
        }
        if (mediaDriver != null) {
            try { mediaDriver.close(); } catch (Exception e) { /* ignore */ }
        }
        log.info("Aeron resources released.");
    }

    public boolean isAvailable() {
        return initialized.get();
    }

    // ── Publish gradient update (called during distributed training) ──────────
    public void publishGradients(INDArray gradients, String jobId, int epoch) {
        if (!initialized.get()) return;

        long startNs = System.nanoTime();
        String channel = config.getAeron().getChannel();
        int streamId = config.getAeron().getStreamId();

        try (Publication publication = aeron.addPublication(channel, streamId)) {
            // Wait up to 500ms for connection
            long deadline = System.currentTimeMillis() + 500;
            while (!publication.isConnected() && System.currentTimeMillis() < deadline) {
                Thread.sleep(5);
            }
            if (!publication.isConnected()) {
                log.debug("Aeron: no subscriber connected, skipping gradient publish");
                // Broadcast "empty" metric so user sees activity
                messagingTemplate.convertAndSend("/topic/aeron-metrics", new Dtos.GradientSyncMetric(
                        jobId, epoch, 0, 0, "NO_SUBSCRIBER", System.currentTimeMillis()));
                return;
            }

            byte[] gradientBytes = serialize(gradients);
            UnsafeBuffer buffer = new UnsafeBuffer(
                    BufferUtil.allocateDirectAligned(gradientBytes.length, 64));
            buffer.putBytes(0, gradientBytes);

            long result;
            int retries = 0;
            do {
                result = publication.offer(buffer, 0, gradientBytes.length);
                if (result < 0) Thread.sleep(1);
                retries++;
            } while (result < 0 && retries < 50);

            long latencyUs = (System.nanoTime() - startNs) / 1000;
            totalGradientsSent.incrementAndGet();
            totalBytesSent.addAndGet(gradientBytes.length);

            // Create and broadcast metric
            Dtos.GradientSyncMetric metric = new Dtos.GradientSyncMetric(
                    jobId, epoch, gradientBytes.length, latencyUs,
                    result >= 0 ? "SENT" : "BACKPRESSURE",
                    System.currentTimeMillis()
            );
            recordMetric(metric);
            messagingTemplate.convertAndSend("/topic/aeron-metrics", metric);

            log.debug("Published {} gradient bytes in {}μs", gradientBytes.length, latencyUs);
        } catch (Exception e) {
            log.warn("Aeron publish failed: {}", e.getMessage());
        }
    }

    // ── Loopback test: publish + subscribe within same JVM ────────────────────
    public Dtos.AeronTestResult runLoopbackTest() {
        if (!initialized.get()) {
            return new Dtos.AeronTestResult(false, "Aeron not initialized", 0, 0, 0);
        }

        String channel = config.getAeron().getChannel();
        int streamId = config.getAeron().getStreamId();
        int testSize = 1000; // 1000 gradient values

        try {
            INDArray testGradients = Nd4j.randn(testSize, 1);
            byte[] serialized = serialize(testGradients);

            long[] receivedBytes = {0};

            // Start subscriber in standard thread
            Thread subscriber = new Thread(() -> {
                try (Subscription subscription = aeron.addSubscription(channel, streamId)) {
                    long deadline = System.currentTimeMillis() + 3000;
                    while (System.currentTimeMillis() < deadline && receivedBytes[0] == 0) {
                        subscription.poll((buffer, offset, length, header) -> {
                            receivedBytes[0] = length;
                        }, 1);
                        Thread.sleep(1);
                    }
                } catch (Exception e) {
                    log.warn("Loopback subscriber error: {}", e.getMessage());
                }
            });
            subscriber.start();

            // Small delay to let subscriber establish
            Thread.sleep(100);

            // Publish
            long startNs = System.nanoTime();
            try (Publication publication = aeron.addPublication(channel, streamId)) {
                long deadline = System.currentTimeMillis() + 2000;
                while (!publication.isConnected() && System.currentTimeMillis() < deadline) {
                    Thread.sleep(5);
                }

                UnsafeBuffer buffer = new UnsafeBuffer(
                        BufferUtil.allocateDirectAligned(serialized.length, 64));
                buffer.putBytes(0, serialized);

                long result;
                int retries = 0;
                do {
                    result = publication.offer(buffer, 0, serialized.length);
                    if (result < 0) Thread.sleep(1);
                    retries++;
                } while (result < 0 && retries < 100);
            }

            subscriber.join(3000);
            long roundTripUs = (System.nanoTime() - startNs) / 1000;

            boolean success = receivedBytes[0] > 0;
            return new Dtos.AeronTestResult(
                    success,
                    success ? "Loopback test PASSED" : "Loopback test FAILED — no data received",
                    roundTripUs,
                    serialized.length,
                    (long) receivedBytes[0]
            );
        } catch (Exception e) {
            return new Dtos.AeronTestResult(false, "Test error: " + e.getMessage(), 0, 0, 0);
        }
    }

    // ── Metrics accessors ─────────────────────────────────────────────────────
    public Dtos.AeronStatus getStatus() {
        return new Dtos.AeronStatus(
                initialized.get(),
                config.getAeron().getChannel(),
                config.getAeron().getStreamId(),
                totalGradientsSent.get(),
                totalGradientsReceived.get(),
                totalBytesSent.get(),
                getAvgLatencyUs(),
                recentMetrics.size()
        );
    }

    public java.util.List<Dtos.GradientSyncMetric> getRecentMetrics() {
        return new java.util.ArrayList<>(recentMetrics);
    }

    private void recordMetric(Dtos.GradientSyncMetric metric) {
        recentMetrics.add(metric);
        while (recentMetrics.size() > MAX_RECENT_METRICS) {
            recentMetrics.remove(0);
        }
    }

    private long getAvgLatencyUs() {
        if (recentMetrics.isEmpty()) return 0;
        return (long) recentMetrics.stream()
                .mapToLong(Dtos.GradientSyncMetric::latencyUs)
                .average().orElse(0);
    }

    // ── Serialization ─────────────────────────────────────────────────────────
    private byte[] serialize(INDArray array) {
        float[] data = array.toFloatVector();
        ByteBuffer buf = ByteBuffer.allocate(4 + data.length * 4);
        buf.putInt(data.length);
        for (float f : data) buf.putFloat(f);
        return buf.array();
    }
}
