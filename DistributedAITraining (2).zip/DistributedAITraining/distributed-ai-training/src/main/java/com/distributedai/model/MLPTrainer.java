package com.distributedai.model;

import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.model.stats.StatsListener;
import org.deeplearning4j.ui.model.storage.InMemoryStatsStorage;
import org.nd4j.evaluation.classification.Evaluation;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.SplitTestAndTrain;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.learning.config.Adam;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.nd4j.linalg.dataset.adapter.SingletonDataSetIterator;
/**
 * MLPTrainer - Month 1 (DA 2)
 *
 * Multi-Layer Perceptron for multi-class classification.
 * Demonstrates:
 *   - Deep architecture: Input → Hidden(256) → Hidden(128) → Output
 *   - ReLU activations + Dropout (via WeightInit/regularization)
 *   - DL4J Training UI at http://localhost:9000
 *   - Train/Test split and Evaluation metrics
 */
public class MLPTrainer {

    private static final Logger log = LoggerFactory.getLogger(MLPTrainer.class);

    // ── Hyperparameters ────────────────────────────────────────────────────────
    private static final int    NUM_INPUTS    = 10;
    private static final int    NUM_CLASSES   = 4;
    private static final int    HIDDEN_1      = 256;
    private static final int    HIDDEN_2      = 128;
    private static final int    NUM_SAMPLES   = 5000;
    private static final int    BATCH_SIZE    = 64;
    private static final int    EPOCHS        = 30;
    private static final double LEARNING_RATE = 0.001;
    private static final long   SEED          = 42L;

    public void train() throws Exception {

        log.info("--- MLP Trainer ---");
        log.info("Architecture: {} → {} → {} → {}", NUM_INPUTS, HIDDEN_1, HIDDEN_2, NUM_CLASSES);

        // ── 1. Start the DL4J Training UI ─────────────────────────────────────
        // Open http://localhost:9000 in your browser while training runs
        UIServer uiServer = UIServer.getInstance();
        InMemoryStatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        log.info("Training UI started at http://localhost:9000");

        // ── 2. Build MLP architecture ──────────────────────────────────────────
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(SEED)
                .weightInit(WeightInit.RELU)           // He init for ReLU layers
                .updater(new Adam(LEARNING_RATE))
                .l2(1e-4)                              // L2 regularization
                .list()

                // Hidden Layer 1: 256 neurons, ReLU
                .layer(new DenseLayer.Builder()
                        .nIn(NUM_INPUTS)
                        .nOut(HIDDEN_1)
                        .activation(Activation.RELU)
                        .build())

                // Hidden Layer 2: 128 neurons, ReLU
                .layer(new DenseLayer.Builder()
                        .nIn(HIDDEN_1)
                        .nOut(HIDDEN_2)
                        .activation(Activation.RELU)
                        .build())

                // Output Layer: Softmax for multi-class classification
                .layer(new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nIn(HIDDEN_2)
                        .nOut(NUM_CLASSES)
                        .activation(Activation.SOFTMAX)
                        .build())

                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();

        // Attach UI stats listener + score logger
        model.setListeners(
                new StatsListener(statsStorage, 10), // sends stats to UI every 10 iters
                new ScoreIterationListener(50)
        );

        log.info("Model summary:\n{}", model.summary());

        // ── 3. Generate synthetic classification dataset ───────────────────────
        DataSet fullData = generateClassificationData(NUM_SAMPLES, NUM_INPUTS, NUM_CLASSES, SEED);
        fullData.shuffle(SEED);

        // 80/20 train-test split
        SplitTestAndTrain split = fullData.splitTestAndTrain(0.8);
        DataSet trainData = split.getTrain();
        DataSet testData  = split.getTest();
        log.info("Train: {} samples | Test: {} samples", trainData.numExamples(), testData.numExamples());

        // ── 4. Train ──────────────────────────────────────────────────────────
        log.info("Training {} epochs, batch size {}...", EPOCHS, BATCH_SIZE);
        for (int epoch = 1; epoch <= EPOCHS; epoch++) {
            model.fit(trainData);
            log.info("Epoch {}/{} complete. Loss: {}", epoch, EPOCHS, String.format("%.4f", model.score()));
        }

        // ── 5. Evaluate on test set ───────────────────────────────────────────
        Evaluation eval = model.evaluate(new SingletonDataSetIterator(testData));
        log.info("=== Test Evaluation ===");
        log.info(eval.stats());

        log.info("MLP training complete. UI still running at http://localhost:9000");
        log.info("Press Ctrl+C to exit.");

        // Keep the UI running so you can inspect it
        Thread.currentThread().join();
    }

    // ── Synthetic multi-class classification data ─────────────────────────────
    private DataSet generateClassificationData(int samples, int features, int classes, long seed) {
        Nd4j.getRandom().setSeed(seed);

        INDArray X      = Nd4j.randn(samples, features);
        INDArray labels = Nd4j.zeros(samples, classes);

        // Simple decision boundary: class = argmax of first 'classes' features
        for (int i = 0; i < samples; i++) {
            int classIdx = 0;
            double maxVal = X.getDouble(i, 0);
            for (int c = 1; c < classes; c++) {
                double val = X.getDouble(i, c);
                if (val > maxVal) { maxVal = val; classIdx = c; }
            }
            labels.putScalar(new int[]{i, classIdx}, 1.0); // one-hot
        }

        log.info("Classification dataset: X={}, labels={}", X.shape(), labels.shape());
        return new DataSet(X, labels);
    }
}
