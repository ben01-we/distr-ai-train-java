package com.distributedai;

import com.distributedai.model.LinearRegressionTrainer;
import com.distributedai.model.MLPTrainer;
import com.distributedai.spark.DistributedTrainingJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MainLauncher - Entry point for the Distributed AI Training System.
 *
 * Usage:
 *   mvn exec:java -Dexec.args="local-linear"    -> Month 1: Linear Regression
 *   mvn exec:java -Dexec.args="local-mlp"       -> Month 1: MLP Neural Network
 *   mvn exec:java -Dexec.args="distributed"     -> Month 2: Spark Distributed
 */
public class MainLauncher {

    private static final Logger log = LoggerFactory.getLogger(MainLauncher.class);

    public static void main(String[] args) throws Exception {

        String mode = (args.length > 0) ? args[0] : "local-mlp";

        log.info("=================================================");
        log.info(" Distributed AI Training System");
        log.info(" Java Version : {}", System.getProperty("java.version"));
        log.info(" Mode         : {}", mode);
        log.info("=================================================");

        switch (mode) {
            case "local-linear" -> {
                log.info("Starting Month 1: Linear Regression Trainer");
                new LinearRegressionTrainer().train();
            }
            case "local-mlp" -> {
                log.info("Starting Month 1: MLP Trainer");
                new MLPTrainer().train();
            }
            case "distributed" -> {
                log.info("Starting Month 2: Distributed Spark Training Job");
                new DistributedTrainingJob().run();
            }
            default -> {
                log.error("Unknown mode '{}'. Use: local-linear | local-mlp | distributed", mode);
                System.exit(1);
            }
        }
    }
}
