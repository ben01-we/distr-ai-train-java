package com.distributedai.service;

import com.distributedai.config.DistributedConfig;
import com.distributedai.model.dto.Dtos;
import com.distributedai.util.ModelFactory;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.spark.impl.multilayer.SparkDl4jMultiLayer;
import org.deeplearning4j.spark.impl.paramavg.ParameterAveragingTrainingMaster;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.adapter.SingletonDataSetIterator;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;

import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import jakarta.annotation.PostConstruct;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * TrainingService - Manages async training jobs and streams
 * real-time metrics to the frontend via WebSocket.
 *
 * Flow:
 * POST /api/training/start
 * → startTrainingJob() [async, runs on background thread]
 * → trains epoch by epoch
 * → broadcasts EpochMetric to /topic/training/{jobId}
 * ← frontend receives live updates via WebSocket subscription
 *
 * Modes:
 * - local-linear: Single-node linear regression (DL4J)
 * - local-mlp: Single-node MLP (DL4J)
 * - distributed: Real Spark cluster training via SparkDl4jMultiLayer
 * with Aeron gradient sync monitoring
 */
@Service
public class TrainingService {

    private static final Logger log = LoggerFactory.getLogger(TrainingService.class);

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private DistributedConfig distributedConfig;

    @Autowired
    private AeronService aeronService;

    // Active job state — thread-safe
    private final ConcurrentHashMap<String, Dtos.JobStatus> jobRegistry = new ConcurrentHashMap<>();
    private final AtomicReference<MultiLayerNetwork> trainedModel = new AtomicReference<>();
    private final AtomicReference<String> activeSparkAppId = new AtomicReference<>();
    private final String SAVED_MODELS_DIR = "saved_models";

    @PostConstruct
    public void init() throws IOException {
        Files.createDirectories(Paths.get(SAVED_MODELS_DIR));
    }

    // ── Start a training job asynchronously ───────────────────────────────────
    @Async
    public void startTrainingJob(String jobId, Dtos.TrainingRequest request) {

        log.info("Job [{}] starting — mode={}, epochs={}", jobId, request.mode(), request.epochs());
        long startTime = System.currentTimeMillis();

        // Mark as RUNNING
        updateJob(jobId, "RUNNING", request.mode(), 0, request.epochs(), 0.0, 0.0,
                System.currentTimeMillis() - startTime, null);

        try {
            switch (request.mode()) {
                case "local-linear" -> runLinearRegression(jobId, request, startTime);
                case "local-mlp" -> runMLP(jobId, request, startTime);
                case "distributed" -> runDistributed(jobId, request, startTime);
                default -> throw new IllegalArgumentException("Unknown mode: " + request.mode());
            }

            updateJob(jobId, "COMPLETED", request.mode(), request.epochs(), request.epochs(),
                    getLastLoss(jobId), 0.0, System.currentTimeMillis() - startTime, null);
            log.info("Job [{}] COMPLETED in {}ms", jobId, System.currentTimeMillis() - startTime);

        } catch (Exception e) {
            log.error("Job [{}] FAILED: {}", jobId, e.getMessage(), e);
            updateJob(jobId, "FAILED", request.mode(), 0, request.epochs(),
                    0.0, 0.0, System.currentTimeMillis() - startTime, e.getMessage());
        }
    }

    // ── Linear Regression Training ────────────────────────────────────────────
    private void runLinearRegression(String jobId, Dtos.TrainingRequest req, long startTime) {
        int numInputs = 3;
        MultiLayerNetwork model = ModelFactory.buildLinearRegression(numInputs);
        DataSet data = generateRegressionData(1000, numInputs);

        for (int epoch = 1; epoch <= req.epochs(); epoch++) {
            model.fit(data);
            double loss = model.score();
            broadcastEpoch(jobId, epoch, req.epochs(), loss, 0.0);
            updateJob(jobId, "RUNNING", req.mode(), epoch, req.epochs(), loss, 0.0,
                    System.currentTimeMillis() - startTime, null);
        }
        trainedModel.set(model);
        try {
            saveModel(model, req.modelName());
        } catch (Exception e) {
            log.error("Save err", e);
        }
    }

    // ── MLP Training ──────────────────────────────────────────────────────────
    private void runMLP(String jobId, Dtos.TrainingRequest req, long startTime) {
        int numInputs = 10, numClasses = 4;
        MultiLayerNetwork model = ModelFactory.buildMLP(numInputs, numClasses);

        DataSet data = generateClassificationData(5000, numInputs, numClasses);
        DataSet testData = generateClassificationData(1000, numInputs, numClasses);

        for (int epoch = 1; epoch <= req.epochs(); epoch++) {
            model.fit(data);
            double loss = model.score();

            // Compute accuracy every 5 epochs (expensive operation)
            double accuracy = 0.0;
            if (epoch % 5 == 0 || epoch == req.epochs()) {
                org.nd4j.evaluation.classification.Evaluation eval = model
                        .evaluate(new SingletonDataSetIterator(testData));
                accuracy = eval.accuracy();
            }

            broadcastEpoch(jobId, epoch, req.epochs(), loss, accuracy);
            updateJob(jobId, "RUNNING", req.mode(), epoch, req.epochs(), loss, accuracy,
                    System.currentTimeMillis() - startTime, null);
        }
        trainedModel.set(model);
        try {
            saveModel(model, req.modelName());
        } catch (Exception e) {
            log.error("Save err", e);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REAL DISTRIBUTED TRAINING — Spark + Aeron
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Runs real distributed training using Apache Spark + DL4J.
     *
     * Flow:
     * 1. Connect to Spark master (configurable URL)
     * 2. Build MLP model via ModelFactory
     * 3. Create ParameterAveragingTrainingMaster (Ring-AllReduce)
     * 4. Distribute training data as an RDD across workers
     * 5. Train epoch-by-epoch, broadcasting real metrics via WebSocket
     * 6. Publish gradient snapshots via Aeron after each epoch
     * 7. Save the trained model
     *
     * If Spark is not available, throws a clear error message.
     */
    private void runDistributed(String jobId, Dtos.TrainingRequest req, long startTime) {

        String masterUrl = distributedConfig.getSpark().getMasterUrl();
        log.info("Job [{}] Distributed mode — connecting to Spark master at {}", jobId, masterUrl);
        broadcastLog(jobId, "Connecting to Spark master: " + masterUrl);

        // ── 1. Verify Spark master is reachable ──────────────────────────────
        if (!isSparkMasterReachable()) {
            throw new RuntimeException(
                    "Cannot connect to Spark master at " + masterUrl + ". " +
                            "Please start the Spark cluster first:\n" +
                            "  $SPARK_HOME/sbin/start-master.sh\n" +
                            "  $SPARK_HOME/sbin/start-worker.sh " + masterUrl);
        }

        int numInputs = 10;
        int numClasses = 4;
        int numSamples = 10_000;
        var sparkCfg = distributedConfig.getSpark();

        // ── 2. Configure Spark ───────────────────────────────────────────────
        SparkConf sparkConf = new SparkConf()
                .setAppName("DistributedAI-Job-" + jobId)
                .setMaster(masterUrl)
                .set("spark.io.compression.codec", "snappy")
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .set("spark.kryo.registrationRequired", "false")
                .set("spark.kryo.registrator", "org.nd4j.kryo.Nd4jRegistrator")
                .set("spark.executor.memory", sparkCfg.getExecutorMemory())
                .set("spark.driver.memory", sparkCfg.getDriverMemory())
                .set("spark.ui.enabled", "false"); // Avoid port conflicts with Spring Boot

        // Provide Hadoop Winutils for Windows natively
        String hadoopPath = new java.io.File("hadoop").getAbsolutePath();
        System.setProperty("hadoop.home.dir", hadoopPath);

        // Windows workaround: Disable Hadoop NativeIO completely to prevent UnsatisfiedLinkError 
        // with mismatched hadoop.dll versions when Spark writes to the filesystem
        try {
            Class<?> nativeIoClass = Class.forName("org.apache.hadoop.io.nativeio.NativeIO");
            java.lang.reflect.Field nativeLoadedField = nativeIoClass.getDeclaredField("nativeLoaded");
            nativeLoadedField.setAccessible(true);
            nativeLoadedField.set(null, false);
            log.info("Disabled Hadoop NativeIO to prevent native access errors.");
        } catch (Throwable t) {
            log.debug("Could not disable Hadoop NativeIO: {}", t.getMessage());
        }

        JavaSparkContext sc = null;

        try {
            sc = new JavaSparkContext(sparkConf);
            String appId = sc.sc().applicationId();
            activeSparkAppId.set(appId);
            log.info("Job [{}] Spark context created. App ID: {}", jobId, appId);
            broadcastLog(jobId, "Spark connected! App ID: " + appId);

            // ── 3. Build the model ───────────────────────────────────────────
            MultiLayerNetwork model = ModelFactory.buildMLP(numInputs, numClasses);
            log.info("Job [{}] Model initialized. Parameters: {}", jobId, model.numParams());
            broadcastLog(jobId, "Model initialized: " + model.numParams() + " parameters");

            // ── 4. Create distributed training strategy ──────────────────────
            ParameterAveragingTrainingMaster trainingMaster = new ParameterAveragingTrainingMaster.Builder(
                    sparkCfg.getBatchSizePerWorker())
                    .averagingFrequency(sparkCfg.getAveragingFrequency())
                    .workerPrefetchNumBatches(sparkCfg.getPrefetchBatches())
                    .batchSizePerWorker(sparkCfg.getBatchSizePerWorker())
                    .repartionData(org.deeplearning4j.spark.api.Repartition.Never)
                    .exportDirectory(null)
                    .build();

            // ── 5. Wrap model for the cluster ────────────────────────────────
            SparkDl4jMultiLayer distributedNetwork = new SparkDl4jMultiLayer(sc, model, trainingMaster);

            // ── 6. Create distributed dataset (RDD) ──────────────────────────
            broadcastLog(jobId, "Generating " + numSamples + " samples and distributing across workers...");
            JavaRDD<DataSet> trainingData = generateDistributedDataset(sc, numSamples, numInputs, numClasses);
            int partitions = trainingData.getNumPartitions();
            log.info("Job [{}] RDD partitions: {}", jobId, partitions);
            broadcastLog(jobId, "Data distributed across " + partitions + " partitions");

            // ── 7. Distributed training loop ─────────────────────────────────
            DataSet localTestData = generateClassificationData(1000, numInputs, numClasses);

            for (int epoch = 1; epoch <= req.epochs(); epoch++) {
                long epochStart = System.currentTimeMillis();

                // Fit on the cluster — this distributes work to all Spark workers
                distributedNetwork.fit(trainingData);

                double loss = distributedNetwork.getScore();
                long epochMs = System.currentTimeMillis() - epochStart;

                // Evaluate accuracy periodically
                double accuracy = 0.0;
                if (epoch % 5 == 0 || epoch == req.epochs()) {
                    MultiLayerNetwork current = distributedNetwork.getNetwork();
                    org.nd4j.evaluation.classification.Evaluation eval = current
                            .evaluate(new SingletonDataSetIterator(localTestData));
                    accuracy = eval.accuracy();
                }

                broadcastEpoch(jobId, epoch, req.epochs(), loss, accuracy);
                updateJob(jobId, "RUNNING", req.mode(), epoch, req.epochs(), loss, accuracy,
                        System.currentTimeMillis() - startTime, null);

                // ── Aeron: publish gradient snapshot ─────────────────────────
                if (aeronService.isAvailable()) {
                    try {
                        INDArray gradientSnapshot = distributedNetwork.getNetwork()
                                .gradient().gradient();
                        aeronService.publishGradients(gradientSnapshot, jobId, epoch);
                    } catch (Exception ae) {
                        log.debug("Aeron gradient publish skipped: {}", ae.getMessage());
                    }
                }

                log.info("Job [{}] Epoch {}/{} loss={} acc={} ({}ms)",
                        jobId, epoch, req.epochs(),
                        String.format("%.4f", loss),
                        String.format("%.4f", accuracy),
                        epochMs);
            }

            // ── 8. Retrieve trained model from cluster ───────────────────────
            MultiLayerNetwork trainedNet = distributedNetwork.getNetwork();
            trainedModel.set(trainedNet);
            saveModel(trainedNet, req.modelName());
            broadcastLog(jobId, "Model saved as '" + req.modelName() + "'");

            // ── 9. Final evaluation ──────────────────────────────────────────
            org.nd4j.evaluation.classification.Evaluation finalEval = trainedNet
                    .evaluate(new SingletonDataSetIterator(localTestData));
            broadcastLog(jobId, "Final accuracy: " + String.format("%.2f%%", finalEval.accuracy() * 100));

            log.info("Job [{}] Distributed training complete", jobId);

        } catch (Exception e) {
            log.error("Job [{}] Distributed training failed: {}", jobId, e.getMessage(), e);
            throw new RuntimeException("Distributed training failed: " + e.getMessage(), e);
        } finally {
            if (sc != null) {
                try {
                    sc.close();
                } catch (Exception e) {
                    /* ignore */ }
                activeSparkAppId.set(null);
                log.info("Job [{}] Spark context closed", jobId);
            }
        }
    }

    // ── Generate RDD for distributed training ─────────────────────────────────
    private JavaRDD<DataSet> generateDistributedDataset(
            JavaSparkContext sc, int samples, int features, int classes) {
        Nd4j.getRandom().setSeed(42L);
        List<DataSet> dataList = new ArrayList<>(samples);
        for (int i = 0; i < samples; i++) {
            INDArray x = Nd4j.randn(1, features);
            INDArray label = Nd4j.zeros(1, classes);
            int classIdx = 0;
            double max = x.getDouble(0, 0);
            for (int j = 1; j < classes && j < features; j++) {
                double v = x.getDouble(0, j);
                if (v > max) {
                    max = v;
                    classIdx = j;
                }
            }
            label.putScalar(new int[] { 0, classIdx }, 1.0);
            dataList.add(new DataSet(x, label));
        }
        return sc.parallelize(dataList);
    }

    // ── Spark reachability check ──────────────────────────────────────────────
    private boolean isSparkMasterReachable() {
        String masterUrl = distributedConfig.getSpark().getMasterUrl();
        if (masterUrl.startsWith("local")) return true;

        // Parse host:port from spark://host:port
        String hostPort = masterUrl.replace("spark://", "");
        String[] parts = hostPort.split(":");
        String host = parts[0];
        int port = parts.length > 1 ? Integer.parseInt(parts[1]) : 7077;

        try (Socket socket = new Socket()) {
            socket.connect(new java.net.InetSocketAddress(host, port), 3000);
            return true;
        } catch (Exception e) {
            log.warn("Spark master not reachable at {}:{} — {}", host, port, e.getMessage());
            return false;
        }
    }

    // ── Cluster info for the dashboard ────────────────────────────────────────
    public Dtos.ClusterInfo getClusterInfo() {
        String masterUrl = distributedConfig.getSpark().getMasterUrl();
        boolean reachable = isSparkMasterReachable();

        if (!reachable) {
            return new Dtos.ClusterInfo(
                    false, masterUrl, 0, 0, 0, null,
                    null, null,
                    "Cannot connect to Spark master at " + masterUrl +
                            ". Start the cluster with: $SPARK_HOME/sbin/start-master.sh");
        }

        // If reachable, try to get worker info via a quick Spark context probe
        if (masterUrl.startsWith("local")) {
            return new Dtos.ClusterInfo(
                    true, masterUrl, Runtime.getRuntime().availableProcessors(),
                    Runtime.getRuntime().availableProcessors(), 0, "local-app",
                    null, "http://localhost:" + distributedConfig.getSpark().getUiPort(),
                    null
            );
        }

        // 1. If a training job is already running, return its App ID directly
        String activeId = activeSparkAppId.get();
        if (activeId != null) {
            return new Dtos.ClusterInfo(
                    true, masterUrl,
                    Runtime.getRuntime().availableProcessors(), // fallback to basic info
                    Runtime.getRuntime().availableProcessors(),
                    0, 
                    activeId,
                    "http://localhost:" + distributedConfig.getSpark().getMasterUiPort(),
                    null, // App UI disabled to fix crash
                    null);
        }

        // 2. Otherwise, perform a quick probe
        try {
            SparkConf probeConf = new SparkConf()
                    .setAppName("ClusterProbe-" + System.currentTimeMillis())
                    .setMaster(masterUrl)
                    .set("spark.ui.enabled", "false");

            try (JavaSparkContext sc = new JavaSparkContext(probeConf)) {
                int defaultParallelism = sc.defaultParallelism();
                String appId = sc.sc().applicationId();

                return new Dtos.ClusterInfo(
                        true, masterUrl,
                        defaultParallelism, // approximate worker count via parallelism
                        defaultParallelism,
                        0, // memory not directly queryable without REST API
                        appId, 
                        "http://localhost:" + distributedConfig.getSpark().getMasterUiPort(),
                        "http://localhost:" + distributedConfig.getSpark().getUiPort(),
                        null);
            }
        } catch (Exception e) {
            return new Dtos.ClusterInfo(
                    true, masterUrl, 0, 0, 0, null,
                    "http://localhost:" + distributedConfig.getSpark().getMasterUiPort(),
                    null,
                    "Spark master reachable but probe failed: " + e.getMessage());
        }
    }

    // ── CSV Training ──────────────────────────────────────────────────────────
    @Async
    public void startTrainingJobCsv(String jobId, Dtos.TrainingRequest request, File csvFile, int numInputs,
            int numClasses) {
        log.info("Job [{}] CSV starting — mode={}", jobId, request.mode());
        long startTime = System.currentTimeMillis();
        updateJob(jobId, "RUNNING", request.mode(), 0, request.epochs(), 0.0, 0.0,
                System.currentTimeMillis() - startTime, null);

        JavaSparkContext sc = null;
        try {
            MultiLayerNetwork model = ModelFactory.buildMLP(numInputs, numClasses);
            RecordReader recordReader = new CSVRecordReader(0, ',');
            recordReader.initialize(new FileSplit(csvFile));
            DataSetIterator iterator = new RecordReaderDataSetIterator(recordReader, 10000, numInputs, numClasses);

            if (!iterator.hasNext())
                throw new IllegalStateException("CSV is empty or unparsable.");
            DataSet allData = iterator.next();
            allData.shuffle();

            if ("distributed".equalsIgnoreCase(request.mode())) {
                log.info("Job [{}] CSV Distributed mode — connecting to Spark", jobId);
                
                // Windows workaround: Disable Hadoop NativeIO
                String hadoopPath = new java.io.File("hadoop").getAbsolutePath();
                System.setProperty("hadoop.home.dir", hadoopPath);
                try {
                    Class<?> nativeIoClass = Class.forName("org.apache.hadoop.io.nativeio.NativeIO");
                    java.lang.reflect.Field nativeLoadedField = nativeIoClass.getDeclaredField("nativeLoaded");
                    nativeLoadedField.setAccessible(true);
                    nativeLoadedField.set(null, false);
                } catch (Throwable t) {}

                var sparkCfg = distributedConfig.getSpark();
                SparkConf sparkConf = new SparkConf()
                        .setAppName("DistributedAI-CSV-" + jobId)
                        .setMaster(sparkCfg.getMasterUrl())
                        .set("spark.io.compression.codec", "snappy")
                        .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                        .set("spark.kryo.registrator", "org.nd4j.kryo.Nd4jRegistrator")
                        .set("spark.executor.memory", sparkCfg.getExecutorMemory())
                        .set("spark.ui.enabled", "false");

                sc = new JavaSparkContext(sparkConf);
                ParameterAveragingTrainingMaster trainingMaster = new ParameterAveragingTrainingMaster.Builder(
                        sparkCfg.getBatchSizePerWorker())
                        .averagingFrequency(sparkCfg.getAveragingFrequency())
                        .workerPrefetchNumBatches(sparkCfg.getPrefetchBatches())
                        .repartionData(org.deeplearning4j.spark.api.Repartition.Never)
                        .exportDirectory(null)
                        .build();

                SparkDl4jMultiLayer distributedNetwork = new SparkDl4jMultiLayer(sc, model, trainingMaster);
                JavaRDD<DataSet> trainingData = sc.parallelize(allData.asList());

                for (int epoch = 1; epoch <= request.epochs(); epoch++) {
                    distributedNetwork.fit(trainingData);
                    double loss = distributedNetwork.getScore();
                    broadcastEpoch(jobId, epoch, request.epochs(), loss, 0.0);
                    updateJob(jobId, "RUNNING", request.mode(), epoch, request.epochs(), loss, 0.0,
                            System.currentTimeMillis() - startTime, null);
                }
                trainedModel.set(distributedNetwork.getNetwork());
            } else {
                // Local Mode
                for (int epoch = 1; epoch <= request.epochs(); epoch++) {
                    model.fit(allData);
                    double loss = model.score();
                    broadcastEpoch(jobId, epoch, request.epochs(), loss, 0.0);
                    updateJob(jobId, "RUNNING", request.mode(), epoch, request.epochs(), loss, 0.0,
                            System.currentTimeMillis() - startTime, null);
                }
                trainedModel.set(model);
            }

            saveModel(trainedModel.get(), request.modelName());
            updateJob(jobId, "COMPLETED", request.mode(), request.epochs(), request.epochs(), getLastLoss(jobId), 0.0,
                    System.currentTimeMillis() - startTime, null);
            log.info("Job [{}] COMPLETED", jobId);

        } catch (Exception e) {
            log.error("Job [{}] CSV FAILED: {}", jobId, e.getMessage());
            updateJob(jobId, "FAILED", request.mode(), 0, request.epochs(), 0.0, 0.0,
                    System.currentTimeMillis() - startTime, e.getMessage());
        } finally {
            if (sc != null) { try { sc.close(); } catch (Exception e) {} }
            if (csvFile != null && csvFile.exists())
                csvFile.delete();
        }
    }

    // ── Model Saving / Loading ────────────────────────────────────────────────
    private void saveModel(MultiLayerNetwork model, String modelName) throws IOException {
        String filename = modelName.endsWith(".zip") ? modelName : modelName + ".zip";
        File f = new File(SAVED_MODELS_DIR, filename);
        ModelSerializer.writeModel(model, f, true);
        log.info("Saved model to {}", f.getAbsolutePath());
    }

    public List<Dtos.SavedModel> getSavedModels() {
        List<Dtos.SavedModel> list = new ArrayList<>();
        File dir = new File(SAVED_MODELS_DIR);
        if (dir.exists() && dir.isDirectory()) {
            for (File f : dir.listFiles((d, name) -> name.endsWith(".zip"))) {
                try {
                    MultiLayerNetwork m = ModelSerializer.restoreMultiLayerNetwork(f, false);
                    long nIn = 10;
                    try {
                        nIn = m.getLayer(0).getParam("W").size(0);
                    } catch (Throwable e) {
                        log.error("Failed to parse nIn for {}: {}", f.getName(), e.getMessage(), e);
                    }
                    list.add(new Dtos.SavedModel(f.getName().replace(".zip", ""), (int) nIn));
                } catch (Exception e) {
                    log.warn("Failed to read model " + f.getName());
                }
            }
        }
        return list;
    }

    public Dtos.SavedModel loadModel(String modelName) throws IOException {
        String filename = modelName.endsWith(".zip") ? modelName : modelName + ".zip";
        File f = new File(SAVED_MODELS_DIR, filename);
        if (!f.exists())
            throw new IllegalArgumentException("Model not found: " + modelName);
        MultiLayerNetwork m = ModelSerializer.restoreMultiLayerNetwork(f, true);
        trainedModel.set(m);
        long nIn = 10;
        try {
            nIn = m.getLayer(0).getParam("W").size(0);
        } catch (Throwable e) {
            log.error("Failed to parse nIn on load for {}: {}", modelName, e.getMessage(), e);
        }
        return new Dtos.SavedModel(modelName, (int) nIn);
    }

    // ── Inference (predict on trained model) ──────────────────────────────────
    public Dtos.PredictResponse predict(Dtos.PredictRequest request) {
        MultiLayerNetwork model = trainedModel.get();
        if (model == null) {
            throw new IllegalStateException("No trained model available. Run a training job first.");
        }

        long t0 = System.currentTimeMillis();
        INDArray input = Nd4j.create(request.features()).reshape(1, request.features().length);
        INDArray output = model.output(input);
        long inferenceMs = System.currentTimeMillis() - t0;

        double[] probs = new double[output.columns()];
        int bestClass = 0;
        double bestProb = 0.0;
        for (int i = 0; i < output.columns(); i++) {
            probs[i] = output.getDouble(0, i);
            if (probs[i] > bestProb) {
                bestProb = probs[i];
                bestClass = i;
            }
        }

        return new Dtos.PredictResponse(bestClass, bestProb, probs, inferenceMs);
    }

    // ── System info ───────────────────────────────────────────────────────────
    public Dtos.SystemInfo getSystemInfo() {
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long maxMb = rt.maxMemory() / (1024 * 1024);
        String nd4jBackend = System.getProperty("org.nd4j.linalg.defaultbackend", "CPU");

        return new Dtos.SystemInfo(
                System.getProperty("java.version"),
                usedMb, maxMb,
                0L, // off-heap tracked by ND4J separately
                rt.availableProcessors(),
                false,
                nd4jBackend);
    }

    // ── Job registry helpers ───────────────────────────────────────────────────
    public Dtos.JobStatus getJob(String jobId) {
        return jobRegistry.getOrDefault(jobId,
                new Dtos.JobStatus(jobId, "NOT_FOUND", null, 0, 0, 0, 0, 0, null));
    }

    public String createJob() {
        String jobId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        jobRegistry.put(jobId, new Dtos.JobStatus(jobId, "IDLE", null, 0, 0, 0, 0, 0, null));
        return jobId;
    }

    private void updateJob(String jobId, String status, String mode, int epoch, int total,
            double loss, double accuracy, long elapsed, String error) {
        jobRegistry.put(jobId, new Dtos.JobStatus(
                jobId, status, mode, epoch, total, loss, accuracy, elapsed, error));
    }

    private void broadcastEpoch(String jobId, int epoch, int total, double loss, double accuracy) {
        Dtos.EpochMetric metric = new Dtos.EpochMetric(
                jobId, epoch, total, loss, accuracy, System.currentTimeMillis());
        messagingTemplate.convertAndSend("/topic/training/" + jobId, metric);
        log.debug("Job [{}] Epoch {}/{} loss={:.4f} acc={:.4f}", jobId, epoch, total, loss, accuracy);
    }

    /** Broadcast a text log message to the frontend */
    private void broadcastLog(String jobId, String message) {
        messagingTemplate.convertAndSend("/topic/training-log/" + jobId,
                java.util.Map.of("jobId", jobId, "message", message, "timestamp", System.currentTimeMillis()));
    }

    private double getLastLoss(String jobId) {
        Dtos.JobStatus s = jobRegistry.get(jobId);
        return s != null ? s.currentLoss() : 0.0;
    }

    // ── Synthetic dataset helpers ─────────────────────────────────────────────
    private DataSet generateRegressionData(int n, int features) {
        INDArray X = Nd4j.rand(n, features);
        INDArray w = Nd4j.create(new double[][] { { 2.0 }, { 3.0 }, { -1.0 } }).castTo(X.dataType());
        INDArray y = X.mmul(w).add(Nd4j.randn(n, 1).mul(0.05));
        return new DataSet(X, y);
    }

    private DataSet generateClassificationData(int n, int features, int classes) {
        Nd4j.getRandom().setSeed(42L);
        INDArray X = Nd4j.randn(n, features);
        INDArray y = Nd4j.zeros(n, classes);
        for (int i = 0; i < n; i++) {
            int c = 0;
            double max = X.getDouble(i, 0);
            for (int j = 1; j < classes; j++) {
                double v = X.getDouble(i, j);
                if (v > max) {
                    max = v;
                    c = j;
                }
            }
            y.putScalar(new int[] { i, c }, 1.0);
        }
        return new DataSet(X, y);
    }
}
