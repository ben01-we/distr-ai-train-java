package com.distributedai.model;

import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.learning.config.Adam;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LinearRegressionTrainer - Month 1 (DA 2)
 *
 * Trains a single-layer linear regression model using DL4J.
 * Demonstrates:
 *   - NeuralNetConfiguration setup
 *   - INDArray tensor creation (ND4J)
 *   - Adam optimizer
 *   - Model evaluation with MSE loss
 */
public class LinearRegressionTrainer {

    private static final Logger log = LoggerFactory.getLogger(LinearRegressionTrainer.class);

    // ── Hyperparameters ────────────────────────────────────────────────────────
    private static final int    NUM_INPUTS    = 3;      // Features per sample
    private static final int    NUM_SAMPLES   = 1000;   // Synthetic dataset size
    private static final int    EPOCHS        = 100;
    private static final double LEARNING_RATE = 0.01;
    private static final long   SEED          = 42L;

    public void train() throws Exception {

        log.info("--- Linear Regression Trainer ---");
        log.info("Inputs: {} | Samples: {} | Epochs: {}", NUM_INPUTS, NUM_SAMPLES, EPOCHS);

        // ── 1. Build the network architecture ─────────────────────────────────
        // Linear Regression = single OutputLayer with IDENTITY activation + MSE loss
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(SEED)
                .weightInit(WeightInit.XAVIER)
                .updater(new Adam(LEARNING_RATE))
                .list()
                .layer(new OutputLayer.Builder(LossFunctions.LossFunction.MSE)
                        .nIn(NUM_INPUTS)
                        .nOut(1)                    // Single regression output
                        .activation(Activation.IDENTITY)
                        .build())
                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();

        // Print loss every 10 iterations
        model.setListeners(new ScoreIterationListener(10));

        log.info("Model architecture:\n{}", model.summary());

        // ── 2. Generate synthetic dataset ─────────────────────────────────────
        // y = 2*x1 + 3*x2 - x3 + noise (true function)
        DataSet dataset = generateSyntheticData(NUM_SAMPLES, NUM_INPUTS, SEED);

        // ── 3. Train ──────────────────────────────────────────────────────────
        log.info("Training for {} epochs...", EPOCHS);
        for (int epoch = 1; epoch <= EPOCHS; epoch++) {
            model.fit(dataset);
            if (epoch % 20 == 0) {
                double score = model.score();
                log.info("  Epoch {:3d} | MSE Loss: {:.6f}", epoch, score);
            }
        }

        // ── 4. Inference demo ─────────────────────────────────────────────────
        INDArray testInput = Nd4j.create(new double[][]{{1.0, 2.0, 0.5}});
        INDArray prediction = model.output(testInput);
        double expected = 2.0 * 1.0 + 3.0 * 2.0 - 0.5; // = 7.5

        log.info("--- Inference ---");
        log.info("Input:      [1.0, 2.0, 0.5]");
        log.info("Predicted:  {}", prediction.getDouble(0));
        log.info("Expected:   ~{}", expected);

        log.info("Linear Regression training complete.");
    }

    // ── Synthetic data: y = 2*x1 + 3*x2 - x3 + gaussian_noise ───────────────
    private DataSet generateSyntheticData(int samples, int features, long seed) {
        Nd4j.getRandom().setSeed(seed);

        INDArray featuresrand1 = Nd4j.rand(samples, features);                    // X in [0,1]
        INDArray weights  = Nd4j.create(new double[][]{{2.0}, {3.0}, {-1.0}}); // True weights
        INDArray noise    = Nd4j.randn(samples, 1).mul(0.05);                  // 5% Gaussian noise
        INDArray labels   = featuresrand1.mmul(weights).add(noise);                 // y = Xw + noise

        log.info("Synthetic dataset ready. Shape: X={}, y={}", featuresrand1.shape(), labels.shape());
        return new DataSet(featuresrand1, labels);
    }
}
