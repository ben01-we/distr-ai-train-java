package com.distributedai.controller;

import com.distributedai.model.dto.Dtos;
import com.distributedai.service.AeronService;
import com.distributedai.service.DataPreprocessingService;
import com.distributedai.service.TrainingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * TrainingController - REST API for the Distributed AI Training System.
 *
 * Endpoints:
 *   POST   /api/training/start        → Start a new training job
 *   GET    /api/training/status/{id}  → Poll job status
 *   POST   /api/predict               → Run inference on trained model
 *   GET    /api/system                → JVM + hardware info
 *   GET    /api/cluster               → Spark cluster status
 *   GET    /api/cluster/aeron         → Aeron gradient sync status
 *   POST   /api/cluster/aeron-test    → Run Aeron loopback test
 *   GET    /api/cluster/aeron-metrics → Recent gradient sync metrics
 *
 * WebSocket:
 *   SUBSCRIBE /topic/training/{jobId}       → Real-time epoch metrics
 *   SUBSCRIBE /topic/training-log/{jobId}   → Real-time training log messages
 *   SUBSCRIBE /topic/aeron-metrics          → Real-time gradient sync metrics
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")  // Allow frontend on any port during development
public class TrainingController {

    private static final Logger log = LoggerFactory.getLogger(TrainingController.class);

    @Autowired
    private TrainingService trainingService;

    @Autowired
    private AeronService aeronService;

    @Autowired
    private DataPreprocessingService preprocessingService;

    // ── POST /api/training/start ───────────────────────────────────────────────
    @PostMapping("/training/start")
    public ResponseEntity<Map<String, String>> startTraining(
            @RequestBody Dtos.TrainingRequest request) {

        String jobId = trainingService.createJob();
        trainingService.startTrainingJob(jobId, request); // Non-blocking (async)

        return ResponseEntity.accepted().body(Map.of(
                "jobId",   jobId,
                "status",  "RUNNING",
                "message", "Training started. Subscribe to /topic/training/" + jobId + " for live metrics.",
                "wsPath",  "/topic/training/" + jobId
        ));
    }

    // ── GET /api/training/status/{jobId} ──────────────────────────────────────
    @GetMapping("/training/status/{jobId}")
    public ResponseEntity<Dtos.JobStatus> getStatus(@PathVariable("jobId") String jobId) {
        return ResponseEntity.ok(trainingService.getJob(jobId));
    }

    // ── POST /api/predict ─────────────────────────────────────────────────────
    @PostMapping("/predict")
    public ResponseEntity<?> predict(@RequestBody Dtos.PredictRequest request) {
        try {
            return ResponseEntity.ok(trainingService.predict(request));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage() != null ? e.getMessage() : "Unknown error"));
        }
    }

    // ── GET /api/system ────────────────────────────────────────────────────────
    @GetMapping("/system")
    public ResponseEntity<Dtos.SystemInfo> systemInfo() {
        return ResponseEntity.ok(trainingService.getSystemInfo());
    }

    // ── POST /api/training/upload-csv ─────────────────────────────────────────
    @PostMapping(value = "/training/upload-csv", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Dtos.JobStatus> uploadCsv(
            @RequestParam("file") MultipartFile file,
            @RequestParam("epochs") int epochs,
            @RequestParam("lr") double lr,
            @RequestParam("batchSize") int batchSize,
            @RequestParam("numInputs") int numInputs,
            @RequestParam("numClasses") int numClasses,
            @RequestParam("modelName") String modelName,
            @RequestParam("mode") String mode) {

        log.info("REST: Starting CSV job — file={}, mode={}", file.getOriginalFilename(), mode);
        String jobId = java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        try {
            File tempFile = File.createTempFile("upload-", ".csv");
            file.transferTo(tempFile);

            Dtos.TrainingRequest request = new Dtos.TrainingRequest(mode, epochs, lr, batchSize, 1, modelName);
            trainingService.startTrainingJobCsv(jobId, request, tempFile, numInputs, numClasses);

            return ResponseEntity.ok(new Dtos.JobStatus(jobId, "RUNNING", mode, 0, epochs, 0.0, 0.0, 0, null));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping(value = "/training/csv-preview", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Dtos.CsvPreviewResponse> previewCsv(@RequestParam("file") MultipartFile file) {
        try {
            File tempFile = File.createTempFile("preview-", ".csv");
            file.transferTo(tempFile);
            Dtos.CsvPreviewResponse response = preprocessingService.getPreview(tempFile);
            tempFile.delete();
            return ResponseEntity.ok(response);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // ── GET /api/models ───────────────────────────────────────────────────────
    @GetMapping("/models")
    public ResponseEntity<java.util.List<Dtos.SavedModel>> getModels() {
        return ResponseEntity.ok(trainingService.getSavedModels());
    }

    // ── POST /api/models/{name}/load ──────────────────────────────────────────
    @PostMapping("/models/{name}/load")
    public ResponseEntity<?> loadModel(@PathVariable("name") String name) {
        try {
            return ResponseEntity.ok(trainingService.loadModel(name));
        } catch (Throwable t) {
            return ResponseEntity.status(500).body(Map.of("error", t.getMessage() != null ? t.getMessage() : t.toString()));
        }
    }

    // ── GET /api/health ────────────────────────────────────────────────────────
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "UP", "service", "Distributed AI Training System"));
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CLUSTER & AERON ENDPOINTS
    // ══════════════════════════════════════════════════════════════════════════

    // ── GET /api/cluster ──────────────────────────────────────────────────────
    @GetMapping("/cluster")
    public ResponseEntity<Dtos.ClusterInfo> clusterInfo() {
        return ResponseEntity.ok(trainingService.getClusterInfo());
    }

    // ── GET /api/cluster/aeron ────────────────────────────────────────────────
    @GetMapping("/cluster/aeron")
    public ResponseEntity<Dtos.AeronStatus> aeronStatus() {
        return ResponseEntity.ok(aeronService.getStatus());
    }

    // ── POST /api/cluster/aeron-test ──────────────────────────────────────────
    @PostMapping("/cluster/aeron-test")
    public ResponseEntity<Dtos.AeronTestResult> aeronTest() {
        return ResponseEntity.ok(aeronService.runLoopbackTest());
    }

    // ── GET /api/cluster/aeron-metrics ────────────────────────────────────────
    @GetMapping("/cluster/aeron-metrics")
    public ResponseEntity<List<Dtos.GradientSyncMetric>> aeronMetrics() {
        return ResponseEntity.ok(aeronService.getRecentMetrics());
    }
}
