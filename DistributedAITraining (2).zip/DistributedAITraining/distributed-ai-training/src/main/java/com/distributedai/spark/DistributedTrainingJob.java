package com.distributedai.spark;

import com.distributedai.util.ModelFactory;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.spark.api.TrainingMaster;
import org.deeplearning4j.spark.impl.multilayer.SparkDl4jMultiLayer;
import org.deeplearning4j.spark.impl.paramavg.ParameterAveragingTrainingMaster;
import org.nd4j.evaluation.classification.Evaluation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * DistributedTrainingJob - Month 2 (DA 3)
 *
 * Runs distributed MLP training using:
 *   - Apache Spark Standalone Cluster (spark://127.0.0.1:7077)
 *   - ParameterAveragingTrainingMaster (Ring-AllReduce style)
 *   - Worker benchmarking: compare 1 vs N workers
 *
 * Prerequisites:
 *   Start the Spark master:  $SPARK_HOME/sbin/start-master.sh
 *   Start a worker:          $SPARK_HOME/sbin/start-worker.sh spark://127.0.0.1:7077
 */
public class DistributedTrainingJob {

    private static final Logger log = LoggerFactory.getLogger(DistributedTrainingJob.class);

    // ── Distributed Hyperparameters ────────────────────────────────────────────
    private static final int BATCH_SIZE_PER_WORKER = 32;
    private static final int AVERAGING_FREQUENCY   = 5;    // Sync weights every 5 batches
    private static final int PREFETCH_BATCHES       = 2;    // Worker prefetch queue depth
    private static final int EPOCHS                 = 20;
    private static final int NUM_SAMPLES            = 10_000;
    private static final int NUM_INPUTS             = 10;
    private static final int NUM_CLASSES            = 4;

    public void run() throws Exception {

        log.info("--- Distributed Training Job ---");
        log.info("Connecting to Spark Standalone at spark://127.0.0.1:7077");

        // ── 1. Configure Spark (Standalone Mode) ──────────────────────────────
        SparkConf sparkConf = new SparkConf()
                .setAppName("DistributedAITraining")
                .setMaster("spark://127.0.0.1:7077")       // Standalone master URI
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .set("spark.kryo.registrator", "org.nd4j.kryo.Nd4jRegistrator")
                .set("spark.kryo.registrationRequired", "false")
                .set("spark.executor.memory", "2g")
                .set("spark.driver.memory", "2g");

        JavaSparkContext sc = new JavaSparkContext(sparkConf);
        log.info("Spark context created. App ID: {}", sc.sc().applicationId());

        try {
            // ── 2. Build the model (same MLP as Month 1) ──────────────────────
            MultiLayerNetwork model = ModelFactory.buildMLP(NUM_INPUTS, NUM_CLASSES);
            log.info("Model initialized. Parameters: {}", model.numParams());

            // ── 3. Define distributed training strategy ────────────────────────
            // ParameterAveragingTrainingMaster implements Ring-AllReduce:
            //   1. Each worker trains on its data shard
            //   2. Every N batches, workers average their gradients
            //   3. Averaged weights are broadcast back to all workers
            ParameterAveragingTrainingMaster trainingMaster = new ParameterAveragingTrainingMaster.Builder(BATCH_SIZE_PER_WORKER)
                    .averagingFrequency(AVERAGING_FREQUENCY)
                    .workerPrefetchNumBatches(PREFETCH_BATCHES)
                    .batchSizePerWorker(BATCH_SIZE_PER_WORKER)
                    .build();

            // ── 4. Wrap model for the cluster ──────────────────────────────────
            SparkDl4jMultiLayer distributedNetwork = new SparkDl4jMultiLayer(sc, model, trainingMaster);

            // ── 5. Create distributed dataset (RDD) ───────────────────────────
            log.info("Generating {} samples and distributing across workers...", NUM_SAMPLES);
            JavaRDD<DataSet> trainingData = generateDistributedDataset(sc, NUM_SAMPLES, NUM_INPUTS, NUM_CLASSES);
            log.info("RDD partitions: {}", trainingData.getNumPartitions());

            // ── 6. Distributed training loop ──────────────────────────────────
            log.info("Starting distributed training for {} epochs...", EPOCHS);
            long startTime = System.currentTimeMillis();

            for (int epoch = 1; epoch <= EPOCHS; epoch++) {
                distributedNetwork.fit(trainingData);
                double score = distributedNetwork.getScore();
                log.info("Epoch {}/{} | Loss: {}", epoch, EPOCHS, String.format("%.4f", score));
            }

            long elapsed = System.currentTimeMillis() - startTime;
            log.info("Training complete in {}ms ({} epochs)", elapsed, EPOCHS);

            // ── 7. Retrieve trained model from cluster and evaluate ────────────
            MultiLayerNetwork trainedModel = distributedNetwork.getNetwork();
            DataSet testData = generateLocalTestSet(1000, NUM_INPUTS, NUM_CLASSES);
            Evaluation eval = trainedModel.evaluate(testData.iterateWithMiniBatches());

            log.info("=== Distributed Model Evaluation ===");
            log.info(eval.stats());

            // ── 8. Save the model ──────────────────────────────────────────────
            String savePath = "trained-model.zip";
            trainedModel.save(new java.io.File(savePath));
            log.info("Model saved to {}", savePath);

        } finally {
            sc.close();
            log.info("Spark context closed.");
        }
    }

    // ── Create an RDD of DataSet objects distributed across workers ───────────
    private JavaRDD<DataSet> generateDistributedDataset(
            JavaSparkContext sc, int samples, int features, int classes) {

        Nd4j.getRandom().setSeed(42L);

        List<DataSet> dataList = new ArrayList<>(samples);
        for (int i = 0; i < samples; i++) {
            INDArray x      = Nd4j.randn(1, features);
            INDArray label  = Nd4j.zeros(1, classes);
            int classIdx    = (int)(Math.abs(x.getDouble(0)) * classes) % classes;
            label.putScalar(new int[]{0, classIdx}, 1.0);
            dataList.add(new DataSet(x, label));
        }

        // Parallelize: Spark distributes partitions across workers automatically
        return sc.parallelize(dataList);
    }

    // ── Local test set for final evaluation ───────────────────────────────────
    private DataSet generateLocalTestSet(int samples, int features, int classes) {
        Nd4j.getRandom().setSeed(99L);
        INDArray X      = Nd4j.randn(samples, features);
        INDArray labels = Nd4j.zeros(samples, classes);
        for (int i = 0; i < samples; i++) {
            int classIdx = (int)(Math.abs(X.getDouble(i, 0)) * classes) % classes;
            labels.putScalar(new int[]{i, classIdx}, 1.0);
        }
        return new DataSet(X, labels);
    }
}
