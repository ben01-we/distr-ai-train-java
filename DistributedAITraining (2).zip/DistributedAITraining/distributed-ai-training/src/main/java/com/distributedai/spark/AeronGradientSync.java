package com.distributedai.spark;

import io.aeron.Aeron;
import io.aeron.Publication;
import io.aeron.Subscription;
import io.aeron.driver.MediaDriver;
import org.agrona.BufferUtil;
import org.agrona.concurrent.UnsafeBuffer;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;

/**
 * AeronGradientSync - Month 2 (DA 3)
 *
 * Demonstrates low-latency UDP gradient synchronization using Aeron.
 *
 * This is an AUXILIARY component that shows how Aeron can be used
 * for custom gradient broadcasting outside of Spark's built-in sync.
 *
 * Architecture:
 *   Worker Node → [publish gradients] → Aeron UDP channel → [subscribe] → Parameter Server
 *
 * Usage (two JVM processes):
 *   Process 1 (Server): new AeronGradientSync().startServer();
 *   Process 2 (Worker): new AeronGradientSync().publishGradients(gradientArray);
 */
public class AeronGradientSync implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(AeronGradientSync.class);

    // Aeron channel and stream IDs
    private static final String CHANNEL   = "aeron:udp?endpoint=localhost:20121";
    private static final int    STREAM_ID = 1001;

    private final MediaDriver mediaDriver;
    private final Aeron aeron;

    public AeronGradientSync() {
        // Launch the embedded media driver (one per JVM)
        this.mediaDriver = MediaDriver.launchEmbedded();

        Aeron.Context ctx = new Aeron.Context()
                .aeronDirectoryName(mediaDriver.aeronDirectoryName());
        this.aeron = Aeron.connect(ctx);

        log.info("Aeron initialized. Channel: {}", CHANNEL);
    }

    /**
     * Publish gradient INDArray over UDP.
     * Called by each worker after local gradient computation.
     */
    public void publishGradients(INDArray gradients) throws InterruptedException {
        try (Publication publication = aeron.addPublication(CHANNEL, STREAM_ID)) {

            // Wait for connection
            while (!publication.isConnected()) {
                Thread.sleep(10);
            }

            // Serialize INDArray to bytes
            byte[] gradientBytes = serialize(gradients);
            UnsafeBuffer buffer = new UnsafeBuffer(
                    BufferUtil.allocateDirectAligned(gradientBytes.length, 64)
            );
            buffer.putBytes(0, gradientBytes);

            // Non-blocking publish with backpressure retry
            long result;
            do {
                result = publication.offer(buffer, 0, gradientBytes.length);
                if (result < 0) Thread.sleep(1);
            } while (result < 0);

            log.debug("Published {} gradient bytes via Aeron UDP", gradientBytes.length);
        }
    }

    /**
     * Subscribe and receive gradient updates.
     * Called by the parameter server / coordinator node.
     */
    public INDArray receiveGradients(int timeoutMs) throws InterruptedException {
        try (Subscription subscription = aeron.addSubscription(CHANNEL, STREAM_ID)) {

            long deadline = System.currentTimeMillis() + timeoutMs;
            INDArray[] received = {null};

            while (System.currentTimeMillis() < deadline && received[0] == null) {
                subscription.poll((buffer, offset, length, header) -> {
                    byte[] bytes = new byte[length];
                    buffer.getBytes(offset, bytes);
                    received[0] = deserialize(bytes);
                    log.debug("Received {} gradient bytes from worker", length);
                }, 1);
                Thread.sleep(1);
            }

            return received[0];
        }
    }

    /**
     * Demo: run a local loopback test to verify Aeron is working.
     */
    public void runLoopbackTest() throws InterruptedException {
        log.info("Running Aeron loopback test...");

        INDArray testGradients = Nd4j.randn(100, 1);  // Simulate 100 gradient values
        log.info("Sending gradients: shape={}", testGradients.shape());

        // Standard Threads (Downgraded from Java 21 Virtual Threads)
        Thread publishThread = new Thread(() -> {
            try {
                publishGradients(testGradients);
                log.info("Publish complete.");
            } catch (Exception e) {
                log.error("Publish failed", e);
            }
        });
        publishThread.start();

        Thread subscribeThread = new Thread(() -> {
            try {
                INDArray received = receiveGradients(5000);
                if (received != null) {
                    log.info("Received gradients: shape={}", received.shape());
                    log.info("Loopback test PASSED.");
                } else {
                    log.warn("Timeout - no gradients received.");
                }
            } catch (Exception e) {
                log.error("Subscribe failed", e);
            }
        });
        subscribeThread.start();

        publishThread.join();
        subscribeThread.join();
    }

    // ── Serialization helpers ─────────────────────────────────────────────────

    private byte[] serialize(INDArray array) {
        // Simple float32 serialization: shape header + raw data
        float[] data   = array.toFloatVector();
        ByteBuffer buf = ByteBuffer.allocate(4 + data.length * 4);
        buf.putInt(data.length);
        for (float f : data) buf.putFloat(f);
        return buf.array();
    }

    private INDArray deserialize(byte[] bytes) {
        ByteBuffer buf    = ByteBuffer.wrap(bytes);
        int length        = buf.getInt();
        float[] data      = new float[length];
        for (int i = 0; i < length; i++) data[i] = buf.getFloat();
        return Nd4j.create(data);
    }

    @Override
    public void close() {
        aeron.close();
        mediaDriver.close();
        log.info("Aeron resources released.");
    }
}
