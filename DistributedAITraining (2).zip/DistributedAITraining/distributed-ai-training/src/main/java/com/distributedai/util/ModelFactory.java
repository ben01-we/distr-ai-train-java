package com.distributedai.util;

import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.learning.config.Adam;
import org.nd4j.linalg.lossfunctions.LossFunctions;

/**
 * ModelFactory - Centralizes model architecture definitions.
 *
 * Used by both local trainers (Month 1) and distributed Spark job (Month 2)
 * so that the same architecture is guaranteed across all workers.
 */
public class ModelFactory {

    private ModelFactory() {}

    /**
     * Builds a single-layer Linear Regression model.
     */
    public static MultiLayerNetwork buildLinearRegression(int numInputs) {
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(42L)
                .weightInit(WeightInit.XAVIER)
                .updater(new Adam(0.01))
                .list()
                .layer(new OutputLayer.Builder(org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction.MSE)
                        .nIn(numInputs).nOut(1)
                        .activation(org.nd4j.linalg.activations.Activation.IDENTITY)
                        .build())
                .build();
        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();
        return model;
    }

    /**
     * Builds the standard MLP used throughout the project.
     * Architecture: inputs → 256 (ReLU) → 128 (ReLU) → classes (Softmax)
     */
    public static MultiLayerNetwork buildMLP(int numInputs, int numClasses) {
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
                .seed(42L)
                .weightInit(WeightInit.RELU)
                .updater(new Adam(0.001))
                .l2(1e-4)
                .list()
                .layer(new DenseLayer.Builder()
                        .nIn(numInputs).nOut(256)
                        .activation(Activation.RELU)
                        .build())
                .layer(new DenseLayer.Builder()
                        .nIn(256).nOut(128)
                        .activation(Activation.RELU)
                        .build())
                .layer(new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nIn(128).nOut(numClasses)
                        .activation(Activation.SOFTMAX)
                        .build())
                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(conf);
        model.init();
        return model;
    }
}
