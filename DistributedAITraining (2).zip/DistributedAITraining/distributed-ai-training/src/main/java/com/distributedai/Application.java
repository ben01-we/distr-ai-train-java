package com.distributedai;

import org.nd4j.linalg.api.buffer.DataType;
import org.nd4j.linalg.factory.Nd4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
/**
 * Application - Spring Boot entry point.
 *
 * Starts the embedded Tomcat server on http://localhost:8080
 * Serves the REST API and WebSocket endpoint.
 *
 * Run: mvn spring-boot:run
 * // ✅ EDIT TEST — this proves Antigravity can edit your files automatically.
 */
@SpringBootApplication
@EnableAsync  // Required for non-blocking async training jobs
public class Application {
    public static void main(String[] args) {
    	Nd4j.setDefaultDataTypes(DataType.FLOAT, DataType.FLOAT);
        SpringApplication.run(Application.class, args);
    }
}
