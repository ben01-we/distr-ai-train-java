package com.distributedai.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * DistributedConfig — Externalized configuration for Spark and Aeron.
 *
 * All values are read from application.properties (prefix: distributed.*).
 * This lets users tune Spark master URL, memory, and Aeron channels
 * without touching code.
 */
@Configuration
@ConfigurationProperties(prefix = "distributed")
public class DistributedConfig {

    private SparkConfig spark = new SparkConfig();
    private AeronConfig aeron = new AeronConfig();

    public SparkConfig getSpark() { return spark; }
    public void setSpark(SparkConfig spark) { this.spark = spark; }
    public AeronConfig getAeron() { return aeron; }
    public void setAeron(AeronConfig aeron) { this.aeron = aeron; }

    public static class SparkConfig {
        private String masterUrl = "spark://127.0.0.1:7077";
        private String executorMemory = "2g";
        private String driverMemory = "2g";
        private int batchSizePerWorker = 32;
        private int averagingFrequency = 5;
        private int prefetchBatches = 2;
        private int uiPort = 4040;
        private int masterUiPort = 8081;

        public String getMasterUrl() { return masterUrl; }
        public void setMasterUrl(String masterUrl) { this.masterUrl = masterUrl; }
        public String getExecutorMemory() { return executorMemory; }
        public void setExecutorMemory(String executorMemory) { this.executorMemory = executorMemory; }
        public String getDriverMemory() { return driverMemory; }
        public void setDriverMemory(String driverMemory) { this.driverMemory = driverMemory; }
        public int getBatchSizePerWorker() { return batchSizePerWorker; }
        public void setBatchSizePerWorker(int batchSizePerWorker) { this.batchSizePerWorker = batchSizePerWorker; }
        public int getAveragingFrequency() { return averagingFrequency; }
        public void setAveragingFrequency(int averagingFrequency) { this.averagingFrequency = averagingFrequency; }
        public int getPrefetchBatches() { return prefetchBatches; }
        public void setPrefetchBatches(int prefetchBatches) { this.prefetchBatches = prefetchBatches; }
        public int getUiPort() { return uiPort; }
        public void setUiPort(int uiPort) { this.uiPort = uiPort; }
        public int getMasterUiPort() { return masterUiPort; }
        public void setMasterUiPort(int masterUiPort) { this.masterUiPort = masterUiPort; }
    }

    public static class AeronConfig {
        private String channel = "aeron:udp?endpoint=localhost:20121";
        private int streamId = 1001;
        private boolean enabled = true;

        public String getChannel() { return channel; }
        public void setChannel(String channel) { this.channel = channel; }
        public int getStreamId() { return streamId; }
        public void setStreamId(int streamId) { this.streamId = streamId; }
        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
    }
}
