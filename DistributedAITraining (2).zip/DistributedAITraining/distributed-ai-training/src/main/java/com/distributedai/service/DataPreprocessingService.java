package com.distributedai.service;

import com.distributedai.model.dto.Dtos;
import org.datavec.api.transform.schema.Schema;
import org.datavec.api.transform.TransformProcess;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class DataPreprocessingService {

    public Dtos.CsvPreviewResponse getPreview(File file) throws IOException {
        List<String[]> samples = new ArrayList<>();
        String[] headers = null;
        int totalRows = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (totalRows == 0) {
                    headers = line.split(",");
                } else if (totalRows <= 10) {
                    samples.add(line.split(","));
                }
                totalRows++;
            }
        }

        String[][] sampleArr = samples.toArray(new String[0][0]);
        String[] types = inferTypes(sampleArr);

        return new Dtos.CsvPreviewResponse(headers, sampleArr, totalRows - 1, types);
    }

    private String[] inferTypes(String[][] samples) {
        if (samples.length == 0) return new String[0];
        int cols = samples[0].length;
        String[] types = new String[cols];

        for (int j = 0; j < cols; j++) {
            boolean isNumeric = true;
            for (String[] sample : samples) {
                if (j >= sample.length) continue;
                try {
                    Double.parseDouble(sample[j]);
                } catch (NumberFormatException e) {
                    isNumeric = false;
                    break;
                }
            }
            types[j] = isNumeric ? "NUMERIC" : "STRING";
        }
        return types;
    }

    public TransformProcess buildTransformProcess(Dtos.CsvSchemaMapping mapping, String[] headers) {
        Schema.Builder builder = new Schema.Builder();
        
        for (String header : headers) {
            Dtos.ColumnRole role = mapping.columns().get(header);
            if (role == null || role == Dtos.ColumnRole.IGNORE) {
                // We'll add it then remove it, or just not add it if Schema supports it?
                // DataVec needs all columns in input schema
                builder.addColumnString(header);
            } else {
                builder.addColumnDouble(header); // Simplify to double for now
            }
        }

        Schema inputSchema = builder.build();
        TransformProcess.Builder tpBuilder = new TransformProcess.Builder(inputSchema);

        // Remove ignored columns
        for (Map.Entry<String, Dtos.ColumnRole> entry : mapping.columns().entrySet()) {
            if (entry.getValue() == Dtos.ColumnRole.IGNORE) {
                tpBuilder.removeColumns(entry.getKey());
            }
        }

        return tpBuilder.build();
    }
}
