package com.distributedai.spark;

import com.distributedai.util.ModelFactory;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.deeplearning4j.spark.impl.multilayer.SparkDl4jMultiLayer;
import org.deeplearning4j.spark.impl.paramavg.ParameterAveragingTrainingMaster;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * BenchmarkRunner - Month 2 (DA 3)
 *
 * Proves horizontal scalability by training with different worker counts
 * and comparing wall-clock time.
 *
 * Run with:   mvn exec:java -Dexec.mainClass="com.distributedai.spark.BenchmarkRunner"
 *
 * Expected output:
 *   Workers=1 | Epochs=10 | Time=XXXXms
 *   Workers=2 | Epochs=10 | Time=XXXXms   (should be ~2x faster)
 *   Workers=4 | Epochs=10 | Time=XXXXms   (should be ~4x faster)
 */
public class BenchmarkRunner {

    private static final Logger log = LoggerFactory.getLogger(BenchmarkRunner.class);

    private static final int   NUM_SAMPLES = 20_000;
    private static final int   NUM_INPUTS  = 10;
    private static final int   NUM_CLASSES = 4;
    private static final int   EPOCHS      = 10;

    public static void main(String[] args) throws Exception {

        log.info("====================================");
        log.info(" Distributed Training Benchmark");
        log.info("====================================");

        int[] workerCounts = {1, 2, 4};
        List<String> results = new ArrayList<>();

        for (int workers : workerCounts) {
            long ms = runBenchmark(workers);
            String result = String.format("Workers=%d | Epochs=%d | Time=%dms (%.2f s)",
                    workers, EPOCHS, ms, ms / 1000.0);
            results.add(result);
            log.info("[RESULT] {}", result);
        }

        log.info("====================================");
        log.info(" Benchmark Summary");
        log.info("====================================");
        results.forEach(r -> log.info("  {}", r));

        // Compute speedup relative to 1 worker
        // (parse from results list in a real benchmark)
        log.info("====================================");
    }

    private static long runBenchmark(int numWorkers) throws Exception {
        log.info("--- Starting benchmark: {} worker(s) ---", numWorkers);

        SparkConf sparkConf = new SparkConf()
                .setAppName("Benchmark-" + numWorkers + "Workers")
                .setMaster("spark://127.0.0.1:7077")
                .set("spark.executor.instances", String.valueOf(numWorkers))
                .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .set("spark.kryo.registrator", "org.nd4j.kryo.Nd4jRegistrator");

        try (JavaSparkContext sc = new JavaSparkContext(sparkConf)) {
            System.out.println("Beginning Benchmark on " + sc.master() + "...");

            var model = ModelFactory.buildMLP(NUM_INPUTS, NUM_CLASSES);

            var trainingMaster = new ParameterAveragingTrainingMaster.Builder(32)
                    .averagingFrequency(5)
                    .workerPrefetchNumBatches(2)
                    .build();

            SparkDl4jMultiLayer network = new SparkDl4jMultiLayer(sc, model, trainingMaster);

            JavaRDD<DataSet> data = generateRDD(sc, NUM_SAMPLES, NUM_INPUTS, NUM_CLASSES);

            long start = System.currentTimeMillis();
            for (int e = 0; e < EPOCHS; e++) {
                network.fit(data);
            }
            long elapsed = System.currentTimeMillis() - start;

            log.info("Workers={} finished in {}ms", numWorkers, elapsed);
            return elapsed;
        }
    }

    private static JavaRDD<DataSet> generateRDD(JavaSparkContext sc, int samples, int features, int classes) {
        Nd4j.getRandom().setSeed(42L);
        List<DataSet> list = new ArrayList<>(samples);
        for (int i = 0; i < samples; i++) {
            INDArray x = Nd4j.randn(1, features);
            INDArray y = Nd4j.zeros(1, classes);
            y.putScalar(new int[]{0, i % classes}, 1.0);
            list.add(new DataSet(x, y));
        }
        return sc.parallelize(list);
    }
}
