package com.distributedai.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Data Transfer Objects for the REST API.
 * All records are immutable and JSON-serializable.
 */
public class Dtos {

    public record TrainingRequest(
            String mode,          // "local-linear" | "local-mlp" | "distributed"
            int    epochs,
            double learningRate,
            int    batchSize,
            int    numWorkers,    // For distributed mode
            String modelName      // Name to save the model as
    ) {
        // Defaults
        public TrainingRequest {
            if (epochs       <= 0) epochs       = 20;
            if (learningRate <= 0) learningRate = 0.001;
            if (batchSize    <= 0) batchSize    = 64;
            if (numWorkers   <= 0) numWorkers   = 1;
            if (mode == null)      mode         = "local-mlp";
            if (modelName == null || modelName.isBlank()) modelName = "model-" + System.currentTimeMillis();
        }
    }

    // ── Response: Saved Model Info ────────────────────────────────────────────
    public record SavedModel(
            String name,
            int numInputs
    ) {}

    // ── Response: Current training job status ─────────────────────────────────
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record JobStatus(
            String jobId,
            String status,        // IDLE | RUNNING | COMPLETED | FAILED
            String mode,
            int    currentEpoch,
            int    totalEpochs,
            double currentLoss,
            double accuracy,
            long   elapsedMs,
            String errorMessage
    ) {}

    // ── Response: Single epoch metric (streamed via WebSocket) ────────────────
    public record EpochMetric(
            String jobId,
            int    epoch,
            int    totalEpochs,
            double loss,
            double accuracy,
            long   timestampMs
    ) {}

    // ── Response: Data split info (streamed via WebSocket) ─────────────────────
    public record DataSplitMetric(
            String jobId,
            int    numPartitions,
            int    totalSamples,
            java.util.List<Integer> partitionSizes,
            long   timestampMs
    ) {}

    // ── Request: Run inference ─────────────────────────────────────────────────
    public record PredictRequest(
            double[] features    // Input feature vector
    ) {}

    // ── Response: Inference result ────────────────────────────────────────────
    public record PredictResponse(
            int      predictedClass,
            double   confidence,
            double[] probabilities,
            long     inferenceMs
    ) {}

    // ── Response: System health ────────────────────────────────────────────────
    public record SystemInfo(
            String  javaVersion,
            long    heapUsedMb,
            long    heapMaxMb,
            long    offHeapMb,
            int     availableCores,
            boolean gpuAvailable,
            String  nd4jBackend
    ) {}

    // ── Response: Spark Cluster info ─────────────────────────────────────────
    public record ClusterInfo(
            boolean sparkReachable,
            String  masterUrl,
            int     activeWorkers,
            long    totalCoresAvailable,
            long    totalMemoryMb,
            String  sparkAppId,
            String  masterUiUrl,
            String  appUiUrl,
            String  errorMessage
    ) {}

    // ── Response: Gradient sync metric (streamed via WebSocket) ───────────────
    public record GradientSyncMetric(
            String jobId,
            int    epoch,
            long   bytesTransferred,
            long   latencyUs,
            String status,           // SENT | BACKPRESSURE | FAILED
            long   timestampMs
    ) {}

    // ── Response: Aeron subsystem status ─────────────────────────────────────
    public record AeronStatus(
            boolean initialized,
            String  channel,
            int     streamId,
            long    totalGradientsSent,
            long    totalGradientsReceived,
            long    totalBytesSent,
            long    avgLatencyUs,
            int     recentMetricCount
    ) {}

    // ── Request: Aeron loopback test result ─────────────────────────────────
    public record AeronTestResult(
            boolean passed,
            String  message,
            long    roundTripUs,
            long    bytesSent,
            long    bytesReceived
    ) {}

    // ── NEW: Advanced Data Preprocessing DTOs ────────────────────────────────
    public record CsvPreviewResponse(
            String[] headers,
            String[][] samples,
            int totalRows,
            String[] inferredTypes
    ) {}

    public record CsvSchemaMapping(
            java.util.Map<String, ColumnRole> columns,
            PreprocessingOptions options
    ) {}

    public enum ColumnRole {
        FEATURE, LABEL, IGNORE
    }

    public record PreprocessingOptions(
            NormalizationType normalization, // NONE | MINMAX | STANDARD
            boolean handleMissingValues,
            boolean shuffle
    ) {}

    public enum NormalizationType {
        NONE, MINMAX, STANDARD
    }
}

