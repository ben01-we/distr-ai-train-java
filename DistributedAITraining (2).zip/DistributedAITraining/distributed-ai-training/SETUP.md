# Distributed AI Training System — Setup & Run Guide

## Project Structure

```
DistributedAITraining/
├── pom.xml                                         ← Maven dependencies + JVM flags
├── SETUP.md                                        ← This file
└── src/main/java/com/distributedai/
    ├── MainLauncher.java                           ← Entry point (switch: local / distributed)
    ├── model/
    │   ├── LinearRegressionTrainer.java            ← Month 1: Linear Regression
    │   └── MLPTrainer.java                         ← Month 1: MLP + DL4J UI
    ├── spark/
    │   ├── DistributedTrainingJob.java             ← Month 2: Spark distributed training
    │   ├── AeronGradientSync.java                  ← Month 2: Aeron UDP gradient sync
    │   └── BenchmarkRunner.java                    ← Month 2: 1 vs N worker benchmark
    └── util/
        └── ModelFactory.java                       ← Shared MLP architecture
```

---

## Month 1 Setup (DA 2) — Local Training

### Step 1: Import into Eclipse

1. **File → Import → Maven → Existing Maven Projects**
2. Select the `DistributedAITraining/` folder
3. Eclipse will download all dependencies (~800MB first time — DL4J is large)

### Step 2: Verify Java 21

```bash
java -version
# Expected: openjdk version "21.x.x" or GraalVM CE 21.x
```

If not on Java 21, in Eclipse go to:
**Window → Preferences → Java → Installed JREs** → Add JDK 21

### Step 3: Run Linear Regression

**In Eclipse:**
- Right-click `MainLauncher.java` → **Run As → Java Application**
- In **Run Configurations → Arguments → Program Arguments**: type `local-linear`

**Or via Maven terminal:**
```bash
cd DistributedAITraining
mvn clean compile exec:java -Dexec.args="local-linear"
```

**Expected output:**
```
Training for 100 epochs...
  Epoch  20 | MSE Loss: 0.024581
  Epoch  40 | MSE Loss: 0.005123
  ...
Input:      [1.0, 2.0, 0.5]
Predicted:  7.487...
Expected:   ~7.5
```

### Step 4: Run MLP with Training UI

```bash
mvn exec:java -Dexec.args="local-mlp"
```

Then open your browser: **http://localhost:9000**

You will see real-time:
- 📉 Loss curve dropping over epochs
- 🧠 Layer activation heatmaps
- 💻 Hardware utilization (CPU/RAM)

---

## Month 2 Setup (DA 3) — Distributed Training

### Step 1: Download Apache Spark

```bash
# Download Spark 3.5.0 (Scala 2.12)
wget https://dlcdn.apache.org/spark/spark-3.5.0/spark-3.5.0-bin-hadoop3.tgz
tar -xzf spark-3.5.0-bin-hadoop3.tgz
export SPARK_HOME=$(pwd)/spark-3.5.0-bin-hadoop3
export PATH=$SPARK_HOME/bin:$PATH
```

### Step 2: Start the Spark Standalone Cluster

**Terminal 1 — Start Master:**
```bash
$SPARK_HOME/sbin/start-master.sh
# Master UI: http://localhost:8080
# Master URI: spark://localhost:7077
```

**Terminal 2 — Start Worker 1:**
```bash
$SPARK_HOME/sbin/start-worker.sh spark://localhost:7077 --memory 2g --cores 2
```

**Terminal 3 — Start Worker 2 (optional, proves scalability):**
```bash
$SPARK_HOME/sbin/start-worker.sh spark://localhost:7077 --memory 2g --cores 2
```

Verify both workers appear at **http://localhost:8080**

### Step 3: Build the Fat JAR

```bash
mvn clean package -DskipTests
# Creates: target/distributed-ai-training-1.0.0.jar
```

### Step 4: Submit the Distributed Job

```bash
spark-submit \
  --master spark://localhost:7077 \
  --driver-memory 2g \
  --executor-memory 2g \
  --class com.distributedai.MainLauncher \
  target/distributed-ai-training-1.0.0.jar \
  distributed
```

**Expected output:**
```
Spark context created. App ID: app-20240101-001
RDD partitions: 8
Starting distributed training for 20 epochs...
Epoch 1/20 | Loss: 1.3862
Epoch 5/20 | Loss: 0.9541
...
=== Distributed Model Evaluation ===
Accuracy: 0.847
Model saved to trained-model.zip
```

### Step 5: Run the Benchmark

Compare training speed across worker counts:

```bash
spark-submit \
  --master spark://localhost:7077 \
  --class com.distributedai.spark.BenchmarkRunner \
  target/distributed-ai-training-1.0.0.jar
```

**Expected benchmark results:**
```
Workers=1 | Epochs=10 | Time=45000ms (45.00 s)
Workers=2 | Epochs=10 | Time=24000ms (24.00 s)
Workers=4 | Epochs=10 | Time=13000ms (13.00 s)
```

This proves **horizontal scalability** for your DA 3 demo.

---

## GPU Setup (Optional, if NVIDIA GPU available)

Replace in `pom.xml`:
```xml
<!-- REMOVE this: -->
<artifactId>nd4j-native-platform</artifactId>

<!-- ADD this (CUDA 11.x): -->
<artifactId>nd4j-cuda-11.6-platform</artifactId>
```

Then set environment variable:
```bash
export CUDA_VISIBLE_DEVICES=0
```

ND4J will automatically offload matrix multiplications to the GPU.

---

## Run Tests

```bash
mvn test
```

Tests verify:
- ✅ MLP output shape is correct
- ✅ Softmax probabilities sum to 1.0
- ✅ Model loss decreases after training
- ✅ Parameter count matches architecture

---

## JVM Flags Explained (from pom.xml)

| Flag | Purpose |
|------|---------|
| `-XX:+UseZGC` | Z Garbage Collector: sub-millisecond GC pauses (critical for training) |
| `--add-modules=jdk.incubator.vector` | Enables Vector API for SIMD CPU acceleration |
| `--enable-native-access=ALL-UNNAMED` | Required for Project Panama (off-heap memory) |
| `-Dorg.bytedeco.javacpp.maxbytes=4G` | ND4J off-heap tensor memory budget |
| `-Xmx4g` | JVM heap (keep this lower than total RAM) |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Connection refused: spark://127.0.0.1:7077` | Run `start-master.sh` first |
| Out of memory during training | Increase `-Xmx` and `javacpp.maxbytes` in pom.xml |
| DL4J UI not showing at :9000 | Check no other process uses port 9000: `lsof -i:9000` |
| Aeron `MediaDriver` error | Only one MediaDriver allowed per JVM — check for duplicate instances |
| Maven download timeout | DL4J dependencies are large (~800MB); retry or use a faster network |
